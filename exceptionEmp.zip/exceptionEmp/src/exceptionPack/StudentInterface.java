package exceptionPack;

public interface StudentInterface {
	public void addstudent();
	public void printstudent();
	//interface will not allow function body.

}
