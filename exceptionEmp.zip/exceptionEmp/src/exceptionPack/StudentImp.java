package exceptionPack;

public class StudentImp implements StudentInterface
{
	String id,name;
	public void addstudent()
	{
		id = "s1234";
		name = "pooja";
		
		
	}
	public void printstudent()
	{
		System.out.println("student id = "+id);
		System.out.println("student name ="+name);
		
	}
	public static void main(String[] args)
	

	{
		StudentImp stImp = new StudentImp();
		stImp.addstudent();
		stImp.printstudent();
		
	}
}
