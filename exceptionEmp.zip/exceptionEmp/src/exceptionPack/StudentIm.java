package exceptionPack;

public class StudentIm extends StudentExmp
{
	
		String id,name;
		public void addStudent()
		{
			id = "s1234";
			name = "pooja";
			
			
		}
		public void printStudent()
		{
			System.out.println("student id = "+id);
			System.out.println("student name ="+name);
			
		}
		public static void main(String[] args) 
		{
			StudentIm stImpl=new StudentIm();
			stImpl.addStudent();
			stImpl.printStudent();
			
		}

	}


	
